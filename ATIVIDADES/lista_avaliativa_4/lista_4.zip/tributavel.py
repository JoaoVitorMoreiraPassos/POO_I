from abc import ABC

class Tributavel(ABC):
    '''
        Essa classe define se uma conta será tritubavél ou não.
    '''
    