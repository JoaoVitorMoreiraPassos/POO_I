from random import randint
from classes import User


class DataBase:
    def __init__(self, clients = []):
        self.clients = clients
    
    def SearchCod(self, cod):
        # busca um usuario pelo seu codigo.
        for i in self.clients:
            if (i.code == cod): return True
        return False
    def SearchUser(self, username, password):
        # Função de login, busca pelo nickname e senha do usuario e verifica se os dois batem.
        for i,v in enumerate(self.clients):
            if (v.username == username) and (v.password == password): return i
        return False
    def InsertClient(self):
        # Insere um novo cliente a lista principal que forma o banco de dados.
        nome = input("Digite seu nome: ")
        username = input("Nome de usuario: ")
        password = input("Sua senha: ")
        matricula = input("Digite sua matricula: ")
        cpf = input("Digite seu cpf: ")
        curso = input("Digite o seu curso: ")
        while True:
            cod = "".join([str(randint(0,9)),str(randint(0,9)),str(randint(0,9)),str(randint(0,9)),str(randint(0,9)),str(randint(0,9)),str(randint(0,9)),str(randint(0,9))])
            if(self.SearchCod(cod)): continue
            else: break
        cliente = User(cod,username, password, nome, matricula, cpf, curso)
        cliente.wallet.code = cod
        cliente.wallet.balance = 0
        self.clients.append(cliente)
        print("Você foi cadastrado com sucesso!")
        return str(len(self.clients)-1)
    
    def ShowBalance(self,indice): return self.clients[indice].wallet.balance
    
    def PutMoney(self, indice):
        quant = float(input("Quantidade do deposito: "))
        self.clients[indice].wallet.balance += quant
        return self.clients[indice].wallet.balance
    
    def TakeMoney(self, indice):
        while True:
            quant = float(input("Valor: "))
            if(quant <= self.clients[indice].wallet.balance):
                self.clients[indice].wallet.balance -= quant
                print("Operação conluida com sucesso!")
                return self.clients[indice].wallet.balance
            else:
                print("Saldo insuficiente: ")
                while True:
                    cancel = input("----1. Tentar novamente\n----2. Sair\nEscolha: ")
                    if (cancel == "2"):
                        print("Operação cancelada")
                        return self.clients[indice].wallet.balance
                    elif (cancel == "1"): break
                    else: print("Valor inválido!")